import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  alumnos: any[] = [
    {repetidor: false, nombre: 'Juan', apellido: 'Lopez', nota: 7.5},
    {repetidor: true, nombre: 'Maria', apellido: 'Sanchez', nota: 6.3},
    {repetidor: true, nombre: 'Pedro', apellido: 'Rodriguez', nota: 3.9},
    {repetidor: false, nombre: 'Elena', apellido: 'Arias', nota: 5.4},
    {repetidor: false, nombre: 'Jorge', apellido: 'Martin', nota: 2.8},
    {repetidor: false, nombre: 'Susana', apellido: 'Gonzalez', nota: 9.3}
  ];

}
