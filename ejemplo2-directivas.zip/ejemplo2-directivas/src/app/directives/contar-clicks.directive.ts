import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[appContarClicks]'
})
export class ContarClicksDirective {

  numeroClicks: number = 15;

  @HostBinding('style.font-size')  // Funciona style.fontSize
  size: string = '';

  @HostBinding('style.opacity')  
  opacidad: number = 0.1;

  constructor() { }

  @HostListener('click')
  procesarClicks(){
    //alert("Has hecho click");
    this.numeroClicks++;
    this.size = (this.numeroClicks + "px");
    this.opacidad += 0.1;
  }

  @HostListener('mouseover')
  procesarRaton() {
    alert("Ratón encima");
  }

}
