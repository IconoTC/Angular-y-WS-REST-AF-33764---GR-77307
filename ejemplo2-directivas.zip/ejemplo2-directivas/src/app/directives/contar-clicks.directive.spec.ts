import { ContarClicksDirective } from './contar-clicks.directive';

describe('ContarClicksDirective', () => {
  it('should create an instance', () => {
    const directive = new ContarClicksDirective();
    expect(directive).toBeTruthy();
  });
});
