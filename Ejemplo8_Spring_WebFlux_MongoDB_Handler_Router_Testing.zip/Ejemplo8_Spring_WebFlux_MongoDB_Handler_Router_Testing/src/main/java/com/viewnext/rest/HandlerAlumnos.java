package com.viewnext.rest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.viewnext.models.Alumno;
import com.viewnext.services.IAlumnosService;

import reactor.core.publisher.Mono;

@Component
public class HandlerAlumnos {
	
	@Autowired
	private IAlumnosService service;
	
	public Mono<ServerResponse> todos(ServerRequest request){
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.consultarTodos(), Alumno.class);
	}
	
	public Mono<ServerResponse> consultarAlumno(ServerRequest request){
		// Comprobar si existe o no ese alumno
		return service.buscarAlumno(request.pathVariable("id"))    // En Mongo el identificador es string
				.flatMap(alum -> ServerResponse.ok()
						.contentType(MediaType.APPLICATION_JSON)
						.body(Mono.just(alum), Alumno.class))
				.switchIfEmpty(ServerResponse.notFound()
				.build());
	}
	
	public Mono<ServerResponse> crearAlumnoREST(ServerRequest request){
		// El alumno viene como parametros REST en la URL
		Alumno nuevo = new Alumno(request.pathVariable("nombre"),
				request.pathVariable("apellido"),
				Double.parseDouble(request.pathVariable("nota")));
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.crearNuevo(nuevo), Alumno.class);
				
	}
	
	public Mono<ServerResponse> crearAlumno(ServerRequest request){
		// El alumno viene en el cuerpo de la peticion
		return request.bodyToMono(Alumno.class)
				.flatMap(body -> ServerResponse.ok()
						.contentType(MediaType.APPLICATION_JSON)
						.body(service.crearNuevo(body), Alumno.class));
					
	}
	
	public Mono<ServerResponse> eliminarAlumno(ServerRequest request){
		// Solucion 1
//		return service.buscarAlumno(request.pathVariable("id"))   
//				.flatMap(alum -> service.eliminarAlumno(alum.getId())
//						.then(ServerResponse.ok().build()))
//						.switchIfEmpty(ServerResponse.notFound()
//								.build());
				
		// Solucion 2
		// No muestra ok() o notFound()
		return service.eliminarAlumno(request.pathVariable("id"))
				.then(ServerResponse.noContent().build());
	}
	
	public Mono<ServerResponse> modificarAlumno(ServerRequest request){
		// El alumno viene en el cuerpo de la peticion
		return request.bodyToMono(Alumno.class)
				.flatMap(body -> ServerResponse.ok()
						.contentType(MediaType.APPLICATION_JSON)
						.body(service.modificarAlumno(body), Alumno.class));			
	}
	

}
