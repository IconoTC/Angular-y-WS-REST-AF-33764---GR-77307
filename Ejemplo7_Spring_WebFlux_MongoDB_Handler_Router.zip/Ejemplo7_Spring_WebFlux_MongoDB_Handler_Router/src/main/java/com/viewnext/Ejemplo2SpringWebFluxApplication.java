package com.viewnext;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.viewnext.models.Alumno;
import com.viewnext.rest.HandlerAlumnos;

@SpringBootApplication
public class Ejemplo2SpringWebFluxApplication implements CommandLineRunner{
	
	@Autowired
	private ReactiveMongoTemplate mongoTemplate;
	
	@Bean
	public RouterFunction<ServerResponse> rutas(HandlerAlumnos handler){
		return RouterFunctions
				// http://localhost:8081/handler/alumnos
				.route(RequestPredicates.GET("/handler/alumnos"), handler::todos)
				// http://localhost:8081/handler/alumnos/67e4248a61c4ec5c2a236288
				.andRoute(RequestPredicates.GET("/handler/alumnos/{id}"), handler::consultarAlumno)
				// http://localhost:8081/handler/alumnos/nombre/Pepito/apellido/Perez/nota/7.3
				.andRoute(RequestPredicates.POST("/handler/alumnos/nombre/{nombre}/apellido/{apellido}/nota/{nota}"), handler::crearAlumnoREST)
				// http://localhost:8081/handler/alumnos
				.andRoute(RequestPredicates.POST("/handler/alumnos"), handler::crearAlumno)
				// http://localhost:8081/handler/alumnos/67e56aa37abbd3785afb5f77
				.andRoute(RequestPredicates.DELETE("/handler/alumnos/{id}"), handler::eliminarAlumno)
				// http://localhost:8081/handler/alumnos
				.andRoute(RequestPredicates.PUT("/handler/alumnos"), handler::modificarAlumno);
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo2SpringWebFluxApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Borrar los datos anteriores
		//mongoTemplate.dropCollection("alumnos").subscribe();
		
		// Crear una lista con 4 alumnos
		List<Alumno> lista = new LinkedList<>(Arrays.asList(
				new Alumno("Juan", "Lopez", 6.5), 
				new Alumno("Pedro", "Rodriguez", 3.5), 
				new Alumno("Maria", "Sanchez", 9.3), 
				new Alumno("Laura", "Fernandez", 7.8) 
				));
		
		//mongoTemplate.insertAll(lista)
		//	.subscribe(System.out::println);
		
	}

}
