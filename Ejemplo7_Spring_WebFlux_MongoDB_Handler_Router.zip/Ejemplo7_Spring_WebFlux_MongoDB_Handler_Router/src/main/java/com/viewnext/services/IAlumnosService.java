package com.viewnext.services;

import com.viewnext.models.Alumno;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface IAlumnosService {
	
	Flux<Alumno> consultarTodos();
	
	Mono<Alumno> buscarAlumno(String id);
	
	Mono<Alumno> crearNuevo(Alumno alumno);
	
	Mono<Void> eliminarAlumno(String id);
	
	Mono<Alumno> modificarAlumno(Alumno alumno);

}
