import { Component } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  amigos: any[] = [];

  amigoForm = new FormGroup({
    id: new FormControl(0),
    nombre: new FormControl(''),
    telefono: new FormControl('')
  });

  constructor(private agendaService: AgendaService){
    this.amigos = agendaService.getAll();
  }

  alta(): void{
    console.log(this.amigoForm.value);
    this.agendaService.nuevoAmigo(this.amigoForm.value);

    // limpiar el formulario
    this.amigoForm.reset();
  }
}
